document.addEventListener("DOMContentLoaded", () => {
  const photoList = document.getElementById("photo-list");
  const photoDetails = document.getElementById("photo-details");

  // Load first 20 photo titles
  fetch("/photos")
    .then(response => response.json())
    .then(data => {
      data.forEach(photo => {
        const li = document.createElement("li");
        li.textContent = photo.title;
        li.addEventListener("click", () => loadPhotoDetails(photo.id));
        photoList.appendChild(li);
      });
    })
    .catch(error => {
      photoList.innerHTML = "<li>Error loading photos.</li>";
      console.error("Fetch error:", error.message);
    });

  // Load single photo details
  function loadPhotoDetails(id) {
    fetch(`/photos/${id}`)
      .then(response => response.json())
      .then(photo => {
        photoDetails.innerHTML = `
          <h2>Photo ID: ${photo.id}</h2>
          <p><strong>Title:</strong> ${photo.title}</p>
          <p><strong>Album ID:</strong> ${photo.albumId}</p>
          <p><strong>URL:</strong> <a href="${photo.url}" target="_blank">${photo.url}</a></p>
          <p><strong>Thumbnail:</strong> <a href="${photo.thumbnailUrl}" target="_blank">${photo.thumbnailUrl}</a></p>
        `;
      })
      .catch(error => {
        photoDetails.innerHTML = "<p>Error loading photo details.</p>";
        console.error("Fetch error:", error.message);
      });
  }
});